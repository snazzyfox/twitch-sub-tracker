import type { HelixUser } from '@twurple/api';
import { DataObject } from '@twurple/common';
import { type EventSubChannelChatSettingsUpdateEventData } from './EventSubChannelChatSettingsUpdateEvent.external';
/**
 * An EventSub event representing chat settings being updated in a channel.
 */
export declare class EventSubChannelChatSettingsUpdateEvent extends DataObject<EventSubChannelChatSettingsUpdateEventData> {
    /**
     * The ID of the broadcaster.
     */
    get broadcasterId(): string;
    /**
     * The name of the broadcaster.
     */
    get broadcasterName(): string;
    /**
     * The display name of the broadcaster.
     */
    get broadcasterDisplayName(): string;
    /**
     * Gets more information about the broadcaster.
     */
    getBroadcaster(): Promise<HelixUser>;
    /**
     * Whether emote only mode is enabled.
     */
    get emoteOnlyModeEnabled(): boolean;
    /**
     * Whether follower only mode is enabled.
     */
    get followerOnlyModeEnabled(): boolean;
    /**
     * The time after which users are able to send messages after following, in minutes.
     *
     * Is `null` if follower only mode is not enabled,
     * but may also be `0` if you can send messages immediately after following.
     */
    get followerOnlyModeDelay(): number | null;
    /**
     * Whether slow mode is enabled.
     */
    get slowModeEnabled(): boolean;
    /**
     * The time to wait between messages in slow mode, in seconds.
     *
     * Is `null` if slow mode is not enabled.
     */
    get slowModeDelay(): number | null;
    /**
     * Whether subscriber only mode is enabled.
     */
    get subscriberOnlyModeEnabled(): boolean;
    /**
     * Whether unique chat mode is enabled.
     */
    get uniqueChatModeEnabled(): boolean;
}
