import type { HelixUser } from '@twurple/api';
import { DataObject } from '@twurple/common';
import { type EventSubAutomaticRewardRedemptionRewardUnlockedEmoteData, type EventSubAutomaticRewardType, type EventSubChannelAutomaticRewardRedemptionAddEventData } from './EventSubChannelAutomaticRewardRedemptionAddEvent.external';
/**
 * An EventSub event representing an automatic reward being redeemed by a user in a channel.
 */
export declare class EventSubChannelAutomaticRewardRedemptionAddEvent extends DataObject<EventSubChannelAutomaticRewardRedemptionAddEventData> {
    /**
     * The ID of the redemption.
     */
    get id(): string;
    /**
     * The ID of the broadcaster in whose channel the reward was redeemed.
     */
    get broadcasterId(): string;
    /**
     * The name of the broadcaster in whose channel the reward was redeemed.
     */
    get broadcasterName(): string;
    /**
     * The display name of the broadcaster in whose channel the reward was redeemed.
     */
    get broadcasterDisplayName(): string;
    /**
     * Gets more information about the broadcaster.
     */
    getBroadcaster(): Promise<HelixUser>;
    /**
     * The ID of the redeeming user.
     */
    get userId(): string;
    /**
     * The name of the redeeming user.
     */
    get userName(): string;
    /**
     * The display name of the redeeming user.
     */
    get userDisplayName(): string;
    /**
     * Gets more information about the banned user.
     */
    getUser(): Promise<HelixUser>;
    /**
     * The type of the reward.
     */
    get rewardType(): EventSubAutomaticRewardType;
    /**
     * The display name of the moderator who issued the ban/timeout.
     */
    get rewardCost(): number;
    /**
     * The emote that was unlocked by the corresponding rewards, or `null` if this field is not relevant.
     */
    get unlockedEmote(): EventSubAutomaticRewardRedemptionRewardUnlockedEmoteData | null;
    /**
     * The input text given by the user.
     *
     * If there is no input to be given, this is an empty string.
     */
    get input(): string | null;
    /**
     * The text of the message, or `null` if there is no message.
     */
    get messageText(): string | null;
    /**
     * The offsets of emote usages in the message, or `null` if there is no message.
     */
    get emoteOffsets(): Map<string, string[]> | null;
    /**
     * The date when the user redeemed the reward.
     */
    get redemptionDate(): Date | null;
}
