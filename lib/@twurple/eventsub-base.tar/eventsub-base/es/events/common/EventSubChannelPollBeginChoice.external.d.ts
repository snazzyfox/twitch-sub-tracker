/** @private */
export interface EventSubChannelPollBeginChoiceData {
    id: string;
    title: string;
}
