/** @private */
export interface EventSubChannelCharityAmountData {
    value: number;
    decimal_places: number;
    currency: string;
}
