/** @private */
export interface EventSubChannelPollVoteTypeSettingsData {
    is_enabled: boolean;
    amount_per_vote: number;
}
