/** @private */
export interface EventSubChannelUnbanEventData {
    user_id: string;
    user_login: string;
    user_name: string;
    broadcaster_user_id: string;
    broadcaster_user_login: string;
    broadcaster_user_name: string;
    moderator_user_id: string;
    moderator_user_login: string;
    moderator_user_name: string;
}
