/** @private */
export interface EventSubStreamOfflineEventData {
    broadcaster_user_id: string;
    broadcaster_user_login: string;
    broadcaster_user_name: string;
}
