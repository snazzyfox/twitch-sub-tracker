import type { HelixUser } from '@twurple/api';
import { DataObject } from '@twurple/common';
import { type EventSubChannelUnbanRequestResolveEventData, type EventSubChannelUnbanRequestStatus } from './EventSubChannelUnbanRequestResolveEvent.external';
/**
 * An EventSub event representing an unban request in a channel.
 */
export declare class EventSubChannelUnbanRequestResolveEvent extends DataObject<EventSubChannelUnbanRequestResolveEventData> {
    /**
     * The ID of the unban request.
     */
    get id(): string;
    /**
     * The ID of the broadcaster in which channel the unban request was resolved.
     */
    get broadcasterId(): string;
    /**
     * The name of the broadcaster in which channel the unban request was resolved.
     */
    get broadcasterName(): string;
    /**
     * The display name of the broadcaster in which channel the unban request was resolved.
     */
    get broadcasterDisplayName(): string;
    /**
     * Gets more information about the broadcaster in which channel the unban request was resolved.
     */
    getBroadcaster(): Promise<HelixUser>;
    /**
     * The ID of the moderator that resolved the unban request.
     */
    get moderatorId(): string;
    /**
     * The name of the moderator that resolved the unban request.
     */
    get moderatorName(): string;
    /**
     * The display name of the moderator that resolved the unban request.
     */
    get moderatorDisplayName(): string;
    /**
     * Gets more information about the moderator that resolved the unban request.
     */
    getModerator(): Promise<HelixUser>;
    /**
     * The ID of the user that requested to be unbanned.
     */
    get userId(): string;
    /**
     * The name of the user that requested to be unbanned.
     */
    get userName(): string;
    /**
     * The display name of the user that requested to be unbanned.
     */
    get userDisplayName(): string;
    /**
     * Gets more information about the user that requested to be unbanned.
     */
    getUser(): Promise<HelixUser>;
    /**
     * Resolution text supplied by the mod/broadcaster upon approval/denial of the request.
     */
    get resolutionMessage(): string | null;
    /**
     * The status of the resolved unban request.
     */
    get status(): EventSubChannelUnbanRequestStatus;
}
