import type { EventSubChannelShieldModeEventData } from './EventSubChannelShieldModeEvent.external';
/** @private */
export interface EventSubChannelShieldModeEndEventData extends EventSubChannelShieldModeEventData {
    ended_at: string;
}
