import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
import { type EventSubChannelChatNotificationSubTier } from './EventSubChannelChatNotificationEvent.external';
/**
 * An EventSub event representing a community sub gift notification in a channel's chat.
 */
export declare class EventSubChannelChatCommunitySubGiftNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "community_sub_gift";
    /**
     * The ID of the community sub gift.
     */
    get id(): string;
    /**
     * The tier of the subscriptions.
     */
    get tier(): EventSubChannelChatNotificationSubTier;
    /**
     * The amount of gifts that are part of this community sub gift.
     */
    get amount(): number;
    /**
     * The amount of gifts that the gifter has sent in total, or `null` the gift is anonymous.
     */
    get cumulativeAmount(): number | null;
}
