import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
/**
 * An EventSub event representing a notification for cancelling an outgoing raid in a channel's chat.
 */
export declare class EventSubChannelChatUnraidNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "unraid";
}
