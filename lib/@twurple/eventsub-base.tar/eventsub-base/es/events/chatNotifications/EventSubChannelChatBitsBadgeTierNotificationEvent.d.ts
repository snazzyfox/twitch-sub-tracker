import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
/**
 * An EventSub event representing a notification for a new bits badge tier being reached in a channel's chat.
 */
export declare class EventSubChannelChatBitsBadgeTierNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "bits_badge_tier";
    /**
     * The new bits badge tier that was just reached.
     */
    get newTier(): number;
}
