import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
import { type EventSubChannelChatNotificationSubTier } from './EventSubChannelChatNotificationEvent.external';
/**
 * An EventSub event representing a notification of a user upgrading their gifted sub to a paid one in a channel's chat.
 */
export declare class EventSubChannelChatPrimePaidUpgradeNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "prime_paid_upgrade";
    get tier(): EventSubChannelChatNotificationSubTier;
}
