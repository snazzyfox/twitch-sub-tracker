import { type HelixUser } from '@twurple/api';
import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
/**
 * An EventSub event representing a notification of a user "paying it forward" in a channel's chat.
 */
export declare class EventSubChannelChatPayItForwardNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "pay_it_forward";
    /**
     * Whether the original gifter is anonymous.
     */
    get isGifterAnonymous(): boolean;
    /**
     * The ID of the original gifter, or `null` if they're anonymous.
     */
    get gifterId(): string | null;
    /**
     * The username of the original gifter, or `null` if they're anonymous.
     */
    get gifterName(): string | null;
    /**
     * The display name of the original gifter, or `null` if they're anonymous.
     */
    get gifterDisplayName(): string | null;
    /**
     * Gets more information about the original gifter, or `null` if they're anonymous.
     */
    getGifter(): Promise<HelixUser | null>;
}
