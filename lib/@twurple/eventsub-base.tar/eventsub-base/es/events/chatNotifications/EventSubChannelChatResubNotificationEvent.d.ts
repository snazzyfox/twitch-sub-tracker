import { type HelixUser } from '@twurple/api';
import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
import { type EventSubChannelChatNotificationSubTier } from './EventSubChannelChatNotificationEvent.external';
/**
 * An EventSub event representing a resub notification in a channel's chat.
 */
export declare class EventSubChannelChatResubNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "resub";
    /**
     * The tier of the subscription.
     */
    get tier(): EventSubChannelChatNotificationSubTier;
    /**
     * Whether the subscription was "paid" for using Prime Gaming.
     */
    get isPrime(): boolean;
    /**
     * The number of months the subscription is for.
     */
    get durationMonths(): number;
    /**
     * The total number of months the user has subscribed for.
     */
    get cumulativeMonths(): number;
    /**
     * The streak amount of months the user has been subscribed for, or `null` if not shared.
     */
    get streakMonths(): number | null;
    /**
     * Whether the resub was gifted by another user.
     */
    get isGift(): boolean;
    /**
     * Whether the gifter is anonymous, or `null` if this is not a gift.
     */
    get isGifterAnonymous(): boolean | null;
    /**
     * The ID of the gifter, or `null` if they're anonymous or this is not a gift.
     */
    get gifterId(): string | null;
    /**
     * The username of the gifter, or `null` if they're anonymous or this is not a gift.
     */
    get gifterName(): string | null;
    /**
     * The display name of the gifter, or `null` if they're anonymous or this is not a gift.
     */
    get gifterDisplayName(): string | null;
    /**
     * Gets more information about the gifter, or `null` if they're anonymous or this is not a gift.
     */
    getGifter(): Promise<HelixUser | null>;
}
