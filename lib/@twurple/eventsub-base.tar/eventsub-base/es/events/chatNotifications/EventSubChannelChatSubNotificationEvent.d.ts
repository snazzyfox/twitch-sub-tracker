import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
import { type EventSubChannelChatNotificationSubTier } from './EventSubChannelChatNotificationEvent.external';
/**
 * An EventSub event representing a sub notification in a channel's chat.
 */
export declare class EventSubChannelChatSubNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "sub";
    /**
     * The tier of the subscription.
     */
    get tier(): EventSubChannelChatNotificationSubTier;
    /**
     * Whether the subscription was "paid" for using Prime Gaming.
     */
    get isPrime(): boolean;
    /**
     * The number of months the subscription is for.
     */
    get durationMonths(): number;
}
