import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
import { type EventSubChannelChatAnnouncementColor } from './EventSubChannelChatNotificationEvent.external';
/**
 * An EventSub event representing a notification for an announcement in a channel's chat.
 */
export declare class EventSubChannelChatAnnouncementNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "announcement";
    /**
     * The color of the announcement.
     */
    get color(): EventSubChannelChatAnnouncementColor;
}
