export {};
//# sourceMappingURL=EventSubChannelRedemptionUpdateSubscription.d.ts.map