export {};
//# sourceMappingURL=EventSubChannelPredictionLockSubscription.d.ts.map