export {};
//# sourceMappingURL=EventSubChannelPollProgressSubscription.d.ts.map