export {};
//# sourceMappingURL=EventSubChannelHypeTrainProgressSubscription.d.ts.map