export {};
//# sourceMappingURL=EventSubChannelGoalEndSubscription.d.ts.map