export {};
//# sourceMappingURL=EventSubChannelChatMessageSubscription.d.ts.map