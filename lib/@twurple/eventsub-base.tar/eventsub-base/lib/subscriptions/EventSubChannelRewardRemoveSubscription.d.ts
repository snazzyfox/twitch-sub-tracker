export {};
//# sourceMappingURL=EventSubChannelRewardRemoveSubscription.d.ts.map