export {};
//# sourceMappingURL=EventSubChannelShoutoutReceiveSubscription.d.ts.map