export {};
//# sourceMappingURL=EventSubChannelPredictionProgressSubscription.d.ts.map