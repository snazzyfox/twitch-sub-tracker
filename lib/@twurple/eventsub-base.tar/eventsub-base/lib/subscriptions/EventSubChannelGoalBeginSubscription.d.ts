export {};
//# sourceMappingURL=EventSubChannelGoalBeginSubscription.d.ts.map