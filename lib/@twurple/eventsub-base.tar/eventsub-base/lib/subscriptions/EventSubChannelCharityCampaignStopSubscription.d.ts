export {};
//# sourceMappingURL=EventSubChannelCharityCampaignStopSubscription.d.ts.map