export {};
//# sourceMappingURL=EventSubChannelAutomaticRewardRedemptionAddSubscription.d.ts.map