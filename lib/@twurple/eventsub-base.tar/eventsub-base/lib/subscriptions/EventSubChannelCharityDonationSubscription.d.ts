export {};
//# sourceMappingURL=EventSubChannelCharityDonationSubscription.d.ts.map