export {};
//# sourceMappingURL=EventSubChannelCharityCampaignProgressSubscription.d.ts.map