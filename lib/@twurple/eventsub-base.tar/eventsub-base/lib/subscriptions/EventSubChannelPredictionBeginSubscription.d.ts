export {};
//# sourceMappingURL=EventSubChannelPredictionBeginSubscription.d.ts.map