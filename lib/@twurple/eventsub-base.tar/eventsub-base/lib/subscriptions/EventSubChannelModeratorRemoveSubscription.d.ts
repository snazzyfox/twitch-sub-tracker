export {};
//# sourceMappingURL=EventSubChannelModeratorRemoveSubscription.d.ts.map