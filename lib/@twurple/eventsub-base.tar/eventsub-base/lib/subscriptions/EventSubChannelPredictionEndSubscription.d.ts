export {};
//# sourceMappingURL=EventSubChannelPredictionEndSubscription.d.ts.map