export {};
//# sourceMappingURL=EventSubChannelUpdateSubscription.d.ts.map