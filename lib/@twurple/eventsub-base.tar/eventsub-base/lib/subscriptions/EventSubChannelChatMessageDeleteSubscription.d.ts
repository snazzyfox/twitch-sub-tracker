export {};
//# sourceMappingURL=EventSubChannelChatMessageDeleteSubscription.d.ts.map