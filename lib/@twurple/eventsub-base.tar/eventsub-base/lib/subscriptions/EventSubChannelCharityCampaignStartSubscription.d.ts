export {};
//# sourceMappingURL=EventSubChannelCharityCampaignStartSubscription.d.ts.map