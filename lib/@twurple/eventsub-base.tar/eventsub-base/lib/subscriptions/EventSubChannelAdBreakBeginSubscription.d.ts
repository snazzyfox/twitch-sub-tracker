export {};
//# sourceMappingURL=EventSubChannelAdBreakBeginSubscription.d.ts.map