export {};
//# sourceMappingURL=EventSubUserAuthorizationGrantSubscription.d.ts.map