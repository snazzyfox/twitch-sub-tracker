export {};
//# sourceMappingURL=EventSubChannelGoalProgressSubscription.d.ts.map