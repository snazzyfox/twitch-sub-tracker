export {};
//# sourceMappingURL=EventSubChannelRewardUpdateSubscription.d.ts.map