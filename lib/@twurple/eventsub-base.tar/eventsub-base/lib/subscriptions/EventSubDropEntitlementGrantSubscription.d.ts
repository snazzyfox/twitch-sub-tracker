export {};
//# sourceMappingURL=EventSubDropEntitlementGrantSubscription.d.ts.map