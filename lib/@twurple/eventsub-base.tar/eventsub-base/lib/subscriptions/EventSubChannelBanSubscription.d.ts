export {};
//# sourceMappingURL=EventSubChannelBanSubscription.d.ts.map