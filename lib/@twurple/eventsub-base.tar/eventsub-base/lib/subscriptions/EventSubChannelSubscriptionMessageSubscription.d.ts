export {};
//# sourceMappingURL=EventSubChannelSubscriptionMessageSubscription.d.ts.map