export {};
//# sourceMappingURL=EventSubChannelShieldModeBeginSubscription.d.ts.map