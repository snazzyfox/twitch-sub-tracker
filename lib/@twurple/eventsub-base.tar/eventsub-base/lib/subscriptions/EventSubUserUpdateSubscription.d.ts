export {};
//# sourceMappingURL=EventSubUserUpdateSubscription.d.ts.map