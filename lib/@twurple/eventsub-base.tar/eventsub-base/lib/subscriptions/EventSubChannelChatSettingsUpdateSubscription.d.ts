export {};
//# sourceMappingURL=EventSubChannelChatSettingsUpdateSubscription.d.ts.map