export {};
//# sourceMappingURL=EventSubChannelFollowSubscription.d.ts.map