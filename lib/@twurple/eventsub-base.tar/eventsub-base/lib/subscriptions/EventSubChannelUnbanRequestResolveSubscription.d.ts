export {};
//# sourceMappingURL=EventSubChannelUnbanRequestResolveSubscription.d.ts.map