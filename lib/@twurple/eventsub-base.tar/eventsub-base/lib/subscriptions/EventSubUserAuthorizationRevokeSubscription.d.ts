export {};
//# sourceMappingURL=EventSubUserAuthorizationRevokeSubscription.d.ts.map