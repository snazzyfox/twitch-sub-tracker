export {};
//# sourceMappingURL=EventSubChannelModeratorAddSubscription.d.ts.map