export {};
//# sourceMappingURL=EventSubChannelRedemptionAddSubscription.d.ts.map