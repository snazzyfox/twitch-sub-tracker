export {};
//# sourceMappingURL=EventSubStreamOnlineSubscription.d.ts.map