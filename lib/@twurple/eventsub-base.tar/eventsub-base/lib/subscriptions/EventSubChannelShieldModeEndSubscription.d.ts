export {};
//# sourceMappingURL=EventSubChannelShieldModeEndSubscription.d.ts.map