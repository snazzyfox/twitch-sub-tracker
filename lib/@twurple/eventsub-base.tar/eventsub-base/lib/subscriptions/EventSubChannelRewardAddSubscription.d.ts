export {};
//# sourceMappingURL=EventSubChannelRewardAddSubscription.d.ts.map