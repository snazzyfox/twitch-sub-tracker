export {};
//# sourceMappingURL=EventSubChannelHypeTrainBeginSubscription.d.ts.map