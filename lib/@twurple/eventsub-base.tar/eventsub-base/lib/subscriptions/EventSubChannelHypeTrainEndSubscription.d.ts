export {};
//# sourceMappingURL=EventSubChannelHypeTrainEndSubscription.d.ts.map