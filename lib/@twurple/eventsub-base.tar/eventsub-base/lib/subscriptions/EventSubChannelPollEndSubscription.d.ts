export {};
//# sourceMappingURL=EventSubChannelPollEndSubscription.d.ts.map