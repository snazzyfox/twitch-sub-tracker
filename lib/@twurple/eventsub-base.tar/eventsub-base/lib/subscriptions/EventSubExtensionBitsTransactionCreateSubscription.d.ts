export {};
//# sourceMappingURL=EventSubExtensionBitsTransactionCreateSubscription.d.ts.map