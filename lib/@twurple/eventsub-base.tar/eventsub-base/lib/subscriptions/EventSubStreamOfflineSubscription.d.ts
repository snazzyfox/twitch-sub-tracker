export {};
//# sourceMappingURL=EventSubStreamOfflineSubscription.d.ts.map