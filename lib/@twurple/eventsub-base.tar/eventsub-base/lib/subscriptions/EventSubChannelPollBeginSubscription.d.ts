export {};
//# sourceMappingURL=EventSubChannelPollBeginSubscription.d.ts.map