export {};
//# sourceMappingURL=EventSubChannelSubscriptionSubscription.d.ts.map