export {};
//# sourceMappingURL=EventSubChannelSubscriptionGiftSubscription.d.ts.map