export {};
//# sourceMappingURL=EventSubChannelShoutoutCreateSubscription.d.ts.map