export {};
//# sourceMappingURL=EventSubChannelChatNotificationSubscription.d.ts.map