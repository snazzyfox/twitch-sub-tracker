import { type HelixUser } from '@twurple/api';
import { DataObject } from '@twurple/common';
import { type EventSubChatMessagePart } from '../common/EventSubChatMessage.external';
import { type EventSubChannelChatBaseNotificationEventData, type EventSubChannelChatNotificationType } from './EventSubChannelChatNotificationEvent.external';
/**
 * An EventSub event representing a notification being sent to a channel's chat.
 */
export declare abstract class EventSubChannelChatBaseNotificationEvent extends DataObject<EventSubChannelChatBaseNotificationEventData> {
    /**
     * The type of the notification.
     */
    abstract readonly type: EventSubChannelChatNotificationType;
    /**
     * The ID of the broadcaster.
     */
    get broadcasterId(): string;
    /**
     * The name of the broadcaster.
     */
    get broadcasterName(): string;
    /**
     * The display name of the broadcaster.
     */
    get broadcasterDisplayName(): string;
    /**
     * Gets more information about the broadcaster.
     */
    getBroadcaster(): Promise<HelixUser>;
    /**
     * Whether the chatter is anonymous.
     *
     * Only applies to some event types like sub gifts.
     */
    get chatterIsAnonymous(): boolean;
    /**
     * The ID of the chatter.
     */
    get chatterId(): string;
    /**
     * The name of the chatter.
     */
    get chatterName(): string;
    /**
     * The display name of the chatter.
     */
    get chatterDisplayName(): string;
    /**
     * Gets more information about the chatter.
     */
    getChatter(): Promise<HelixUser>;
    /**
     * The color of the chatter, or null if they didn't choose a color.
     */
    get color(): string | null;
    /**
     * The badges the chatter has.
     *
     * The returned object contains the badge names as keys and the badge versions as the respective values.
     */
    get badges(): Record<string, string>;
    /**
     * Checks whether the chatter has the specified badge.
     *
     * @param name The name of the badge to check.
     */
    hasBadge(name: string): boolean;
    /**
     * Gets the badge info for a specified badge, or null if the badge does not exist.
     *
     * @param name The name of the badge to get info for.
     */
    getBadgeInfo(name: string): string | null;
    /**
     * The ID of the notification message.
     */
    get messageId(): string;
    /**
     * The text that was sent with the notification, e.g. the resub message or announcement text.
     */
    get messageText(): string;
    /**
     * The text that was sent with the notification, structured into pre-parsed parts.
     */
    get messageParts(): EventSubChatMessagePart[];
}
//# sourceMappingURL=EventSubChannelChatBaseNotificationEvent.d.ts.map