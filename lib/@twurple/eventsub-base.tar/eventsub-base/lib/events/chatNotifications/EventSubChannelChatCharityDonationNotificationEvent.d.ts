import { EventSubChannelCharityAmount } from '../common/EventSubChannelCharityAmount';
import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
/**
 * An EventSub event representing a notification for a charity donation in a channel's chat.
 */
export declare class EventSubChannelChatCharityDonationNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "charity_donation";
    /**
     * The name of the charity that was donated to.
     */
    get charityName(): string;
    /**
     * The amount of money that was donated.
     */
    get amount(): EventSubChannelCharityAmount;
}
//# sourceMappingURL=EventSubChannelChatCharityDonationNotificationEvent.d.ts.map