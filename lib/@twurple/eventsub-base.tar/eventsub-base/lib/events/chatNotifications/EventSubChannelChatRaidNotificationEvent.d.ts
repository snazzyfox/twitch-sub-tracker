import { type HelixUser } from '@twurple/api';
import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
/**
 * An EventSub event representing an incoming raid notification in a channel's chat.
 */
export declare class EventSubChannelChatRaidNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "raid";
    /**
     * The ID of the user that raided the channel.
     */
    get raiderId(): string;
    /**
     * The username of the user that raided the channel.
     */
    get raiderName(): string;
    /**
     * The display name of the user that raided the channel.
     */
    get raiderDisplayName(): string;
    /**
     * Gets more information about the user that raided the channel.
     */
    getRaider(): Promise<HelixUser>;
    /**
     * The amount of viewers the channel was raided with.
     */
    get viewerCount(): number;
    /**
     * The URL to the profile image of the user that raided the channel.
     */
    get raiderProfileImageUrl(): string;
}
//# sourceMappingURL=EventSubChannelChatRaidNotificationEvent.d.ts.map