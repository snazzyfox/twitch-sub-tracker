import { type HelixUser } from '@twurple/api';
import { EventSubChannelChatBaseNotificationEvent } from './EventSubChannelChatBaseNotificationEvent';
import { type EventSubChannelChatNotificationSubTier } from './EventSubChannelChatNotificationEvent.external';
/**
 * An EventSub event representing a sub gift notification in a channel's chat.
 */
export declare class EventSubChannelChatSubGiftNotificationEvent extends EventSubChannelChatBaseNotificationEvent {
    readonly type = "sub_gift";
    /**
     * The tier of the subscription.
     */
    get tier(): EventSubChannelChatNotificationSubTier;
    /**
     * The number of months the subscription is for.
     */
    get durationMonths(): number;
    /**
     * The amount of gifts that the gifter has sent in total, or `null` the gift is anonymous.
     */
    get cumulativeAmount(): number | null;
    /**
     * The ID of the recipient.
     */
    get recipientId(): string;
    /**
     * The username of the recipient.
     */
    get recipientName(): string;
    /**
     * The display name of the recipient.
     */
    get recipientDisplayName(): string;
    /**
     * Gets more information about the recipient.
     */
    getRecipient(): Promise<HelixUser>;
    /**
     * The id of the community gift the sub gift belongs to, or `null` if it doesn't belong to any community gift.
     */
    get communityGiftId(): string | null;
}
//# sourceMappingURL=EventSubChannelChatSubGiftNotificationEvent.d.ts.map