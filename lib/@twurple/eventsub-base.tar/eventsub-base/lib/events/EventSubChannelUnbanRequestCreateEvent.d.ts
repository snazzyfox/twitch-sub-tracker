import type { HelixUser } from '@twurple/api';
import { DataObject } from '@twurple/common';
import { type EventSubChannelUnbanRequestCreateEventData } from './EventSubChannelUnbanRequestCreateEvent.external';
/**
 * An EventSub event representing a broadcaster shouting out another broadcaster.
 */
export declare class EventSubChannelUnbanRequestCreateEvent extends DataObject<EventSubChannelUnbanRequestCreateEventData> {
    /**
     * The ID of the unban request.
     */
    get id(): string;
    /**
     * The ID of the broadcaster the unban request was created for.
     */
    get broadcasterId(): string;
    /**
     * The name of the broadcaster the unban request was created for.
     */
    get broadcasterName(): string;
    /**
     * The display name of the broadcaster the unban request was created for.
     */
    get broadcasterDisplayName(): string;
    /**
     * Gets more information about the broadcaster in which channel the unban request was created for.
     */
    getBroadcaster(): Promise<HelixUser>;
    /**
     * The ID of the user that is requesting to be unbanned.
     */
    get userId(): string;
    /**
     * The name of the user that is requesting to be unbanned.
     */
    get userName(): string;
    /**
     * The display name of the user that is requesting to be unbanned.
     */
    get userDisplayName(): string;
    /**
     * Gets more information about the user that requested to be unbanned.
     */
    getUser(): Promise<HelixUser>;
    /**
     * The message sent in the unban request.
     */
    get message(): string;
    /**
     * Date when the unban request was created.
     */
    get creationDate(): Date;
}
//# sourceMappingURL=EventSubChannelUnbanRequestCreateEvent.d.ts.map