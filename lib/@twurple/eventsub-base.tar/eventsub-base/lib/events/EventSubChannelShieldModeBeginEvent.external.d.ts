import type { EventSubChannelShieldModeEventData } from './EventSubChannelShieldModeEvent.external';
/** @private */
export interface EventSubChannelShieldModeBeginEventData extends EventSubChannelShieldModeEventData {
    started_at: string;
}
//# sourceMappingURL=EventSubChannelShieldModeBeginEvent.external.d.ts.map