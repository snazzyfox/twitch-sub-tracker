import type { EventSubChannelShieldModeEventData } from './EventSubChannelShieldModeEvent.external';
/** @private */
export interface EventSubChannelShieldModeEndEventData extends EventSubChannelShieldModeEventData {
    ended_at: string;
}
//# sourceMappingURL=EventSubChannelShieldModeEndEvent.external.d.ts.map