/** @private */
export interface EventSubChannelPredictionPredictorData {
    user_name: string;
    user_login: string;
    user_id: string;
    channel_points_won: number | null;
    channel_points_used: number;
}
//# sourceMappingURL=EventSubChannelPredictionPredictor.external.d.ts.map