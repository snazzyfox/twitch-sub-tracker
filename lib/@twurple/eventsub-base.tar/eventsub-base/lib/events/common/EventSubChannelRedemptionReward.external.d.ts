/** @private */
export interface EventSubChannelRedemptionRewardData {
    id: string;
    title: string;
    cost: number;
    prompt: string;
}
//# sourceMappingURL=EventSubChannelRedemptionReward.external.d.ts.map