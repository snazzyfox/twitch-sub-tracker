/** @private */
export interface EventSubChannelPollBeginChoiceData {
    id: string;
    title: string;
}
//# sourceMappingURL=EventSubChannelPollBeginChoice.external.d.ts.map