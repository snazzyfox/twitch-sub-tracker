/** @private */
export interface EventSubChannelCharityAmountData {
    value: number;
    decimal_places: number;
    currency: string;
}
//# sourceMappingURL=EventSubChannelCharityAmount.external.d.ts.map