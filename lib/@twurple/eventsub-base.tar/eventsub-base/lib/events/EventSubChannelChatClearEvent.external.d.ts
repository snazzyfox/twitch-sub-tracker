/** @private */
export interface EventSubChannelChatClearEventData {
    broadcaster_user_id: string;
    broadcaster_user_login: string;
    broadcaster_user_name: string;
}
//# sourceMappingURL=EventSubChannelChatClearEvent.external.d.ts.map