import { type HelixUser } from '@twurple/api';
import { DataObject } from '@twurple/common';
import { type EventSubChatMessagePart } from './common/EventSubChatMessage.external';
import { type EventSubChannelChatMessageEventData } from './EventSubChannelChatMessageEvent.external';
/**
 * An EventSub event representing a notification being sent to a channel's chat.
 */
export declare class EventSubChannelChatMessageEvent extends DataObject<EventSubChannelChatMessageEventData> {
    /**
     * The type of the message.
     */
    get messageType(): string;
    /**
     * The ID of the broadcaster.
     */
    get broadcasterId(): string;
    /**
     * The name of the broadcaster.
     */
    get broadcasterName(): string;
    /**
     * The display name of the broadcaster.
     */
    get broadcasterDisplayName(): string;
    /**
     * Gets more information about the broadcaster.
     */
    getBroadcaster(): Promise<HelixUser>;
    /**
     * The ID of the chatter.
     */
    get chatterId(): string;
    /**
     * The name of the chatter.
     */
    get chatterName(): string;
    /**
     * The display name of the chatter.
     */
    get chatterDisplayName(): string;
    /**
     * Gets more information about the chatter.
     */
    getChatter(): Promise<HelixUser>;
    /**
     * The color of the chatter, or null if they didn't choose a color.
     */
    get color(): string | null;
    /**
     * The badges the chatter has.
     *
     * The returned object contains the badge names as keys and the badge versions as the respective values.
     */
    get badges(): Record<string, string>;
    /**
     * Checks whether the chatter has the specified badge.
     *
     * @param name The name of the badge to check.
     */
    hasBadge(name: string): boolean;
    /**
     * Gets the badge info for a specified badge, or null if the badge does not exist.
     *
     * @param name The name of the badge to get info for.
     */
    getBadgeInfo(name: string): string | null;
    /**
     * The ID of the notification message.
     */
    get messageId(): string;
    /**
     * The text that was sent with the notification, e.g. the resub message or announcement text.
     */
    get messageText(): string;
    /**
     * The text that was sent with the notification, structured into pre-parsed parts.
     */
    get messageParts(): EventSubChatMessagePart[];
    /**
     * The ID of the message that this message is a reply to, or `null` if it's not a reply.
     */
    get parentMessageId(): string | null;
    /**
     * The text of the message that this message is a reply to, or `null` if it's not a reply.
     */
    get parentMessageText(): string | null;
    /**
     * The ID of the user that wrote the message that this message is a reply to, or `null` if it's not a reply.
     */
    get parentMessageUserId(): string | null;
    /**
     * The name of the user that wrote the message that this message is a reply to, or `null` if it's not a reply.
     */
    get parentMessageUserName(): string | null;
    /**
     * The display name of the user that wrote the message that this message is a reply to, or `null` if it's not a reply.
     */
    get parentMessageUserDisplayName(): string | null;
    /**
     * The ID of the message that is the thread starter of this message, or `null` if it's not a reply.
     */
    get threadMessageId(): string | null;
    /**
     * The ID of the user that wrote the thread starter message of this message, or `null` if it's not a reply.
     */
    get threadMessageUserId(): string | null;
    /**
     * The name of the user that wrote the thread starter message of this message, or `null` if it's not a reply.
     */
    get threadMessageUserName(): string | null;
    /**
     * The display name of the user that wrote the thread starter message of this message, or `null` if it's not a reply.
     */
    get threadMessageUserDisplayName(): string | null;
    /**
     * Whether the message is a cheer.
     */
    get isCheer(): boolean;
    /**
     * The number of bits cheered with this message.
     */
    get bits(): number;
    /**
     * Whether the message represents a redemption of a custom channel points reward.
     */
    get isRedemption(): boolean;
    /**
     * The ID of the redeemed reward, or `null` if the message does not represent a redemption.
     */
    get rewardId(): string | null;
}
//# sourceMappingURL=EventSubChannelChatMessageEvent.d.ts.map