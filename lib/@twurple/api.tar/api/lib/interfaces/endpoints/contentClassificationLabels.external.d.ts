/** @private */
export interface HelixContentClassificationLabelData {
    id: string;
    description: string;
    name: string;
}
//# sourceMappingURL=contentClassificationLabels.external.d.ts.map