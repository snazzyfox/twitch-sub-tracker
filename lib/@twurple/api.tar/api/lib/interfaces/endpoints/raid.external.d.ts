/** @private */
export interface HelixRaidData {
    created_at: string;
    is_mature: boolean;
}
//# sourceMappingURL=raid.external.d.ts.map