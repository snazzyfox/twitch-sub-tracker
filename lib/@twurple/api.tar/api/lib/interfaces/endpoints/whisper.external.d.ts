export {};
//# sourceMappingURL=whisper.external.d.ts.map