import { BaseApiClient } from './BaseApiClient';
/** @private */
export declare class NoContextApiClient extends BaseApiClient {
}
//# sourceMappingURL=NoContextApiClient.d.ts.map