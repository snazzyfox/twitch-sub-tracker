import { BaseApiClient } from './BaseApiClient';
/** @private */
export declare class UserContextApiClient extends BaseApiClient {
    private readonly _userId;
}
//# sourceMappingURL=UserContextApiClient.d.ts.map