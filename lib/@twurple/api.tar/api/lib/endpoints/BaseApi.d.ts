/** @private */
export declare class BaseApi {
}
//# sourceMappingURL=BaseApi.d.ts.map