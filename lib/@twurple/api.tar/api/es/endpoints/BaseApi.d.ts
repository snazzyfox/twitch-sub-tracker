/** @private */
export declare class BaseApi {
}
