/** @private */
export interface HelixGameData {
    id: string;
    name: string;
    box_art_url: string;
    igdb_id: string;
}
