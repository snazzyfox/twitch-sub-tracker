import { BaseApiClient } from './BaseApiClient';
/** @private */
export declare class NoContextApiClient extends BaseApiClient {
}
