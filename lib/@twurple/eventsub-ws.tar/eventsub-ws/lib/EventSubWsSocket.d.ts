export {};
//# sourceMappingURL=EventSubWsSocket.d.ts.map